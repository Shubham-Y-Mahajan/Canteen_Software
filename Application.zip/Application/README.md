# To run Software - run main.exe file
## Do not delete any files/folders in the 'Application' directory 
( main.exe , student_database.db and Reports/ must belong in the same directory for the software to function properly )

# Canteen software created by Group - Three Musketeers
-Shubham Mahajan
-Aditya Bajpai
-Janmay Patel
